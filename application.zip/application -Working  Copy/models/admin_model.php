<?php
class Dashboard_model extends CI_Model{

	public function __construct(){
			$this->load->database();
	}
	
		public function get_users(){
        if ($id === 0)
        {
                $query = $this->db->get('user');
                return $query->result_array();
        }
        $query = $this->db->get_where('user', array('id' => $id));
        return $query->row_array();
}

	}
	public function get_users_by_id($id = 0){
		 if ($id === 0)
        {
            $query = $this->db->get('users');
            return $query->result_array();
        }
 
        $query = $this->db->get_where('users', array('id' => $id));
        return $query->row_array();
    }
	public function edit(){
	$id = $this->uri->segment(3);

	if (empty($id)){
		show_404();
	}

	$this->load->helper('form');
	$this->load->library('form_validation');

	$data['title'] = 'Edit a dashboard item';
	$data['users'] = $this->user_model->get_user_by_id($id);
	
	$this->form_validation->set_rules('brand', 'Brand', 'required');
	$this->form_validation->set_rules('model', 'Model', 'required');
	$this->form_validation->set_rules('colour', 'Colour', 'required');
	$this->form_validation->set_rules('date_added', 'Date_Added', 'required');
	$this->form_validation->set_rules('year_made', 'Year_Made', 'required');
	
	if ($this->form_validation->run() === FALSE){
	$this->load->view('templates/header', $data);
	$this->load->view('dashboard/edit', $data);
	$this->load->view('templates/footer');

	}else{

	$this->dashboard_model->set_dashboard($id);
	redirect( site_url('dashboard'));
	}
}




	public function delete_user($id)
	{
		$this->db->where('id',$id);
		return $this->db->delete('user');
	}
}
}