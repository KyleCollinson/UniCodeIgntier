<?php
echo '<h2>'.$dashboard_item['brand'].'</h2>';
echo $dashboard_item['model'];
echo $dashboard_item['colour'];
echo $dashboard_item['date_added'];
echo $dashboard_item['year_made'];