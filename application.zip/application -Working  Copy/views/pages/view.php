<?php
echo '<h2>'.$dashboard_item['title'].'</h2>';
echo $dashboard_item['text'];