<p> Added Sucessfully!</p>
<p>
<a href="<?php echo site_url('dashboard/'); ?>">Back to Listings</a>
</p>