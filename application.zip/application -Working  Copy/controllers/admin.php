<?php
class Dashboard extends CI_Controller {

public function __construct()
{
parent::__construct();
		$this->load->helper('url_helper');
		$this->load->model('user_model');
		$this->load->library('session');
		$this->load->library('pagination');
}

public function index(){
	
		$this->load->helper('form');
		$this->load->library('form_validation');

		$data['title'] = 'Admin View';
		$data['admin'] = $this->user_model->get_user();
		$this->load->view('templates/header' );
		$this->load->view('dashboard/index',$data);
		$this->load->view('templates/footer');

       

                               

}
public function view($slug = NULL){
	$data['users'] = $this->user_model->get_user($slug);

	if (empty($data['users'])){
		show_404();
	}

	$data['title'] = $data['users']['title'];

	$this->load->view('templates/header', $data);
	$this->load->view('dashboard/view', $data);
	$this->load->view('templates/footer');
}


public function edit_users(){
		if (!$this->session->userdata('is_logged_in'))
	{
		redirect(site_url('user/login'));
	}else {
		$data['user_id'] = $this->session->userdata['user_id'];
		  }
	$id = $this->uri->segment(3);

	if (empty($id)){
		show_404();
	}

	$this->load->helper('form');
	$this->load->library('form_validation');

	$data['title'] = 'Edit a users details';
	$data['users'] = $this->dashboard_model->get_dashboard_by_id($id);

	
	
		$this->form_validation->set_rules('firstname', 'First Name', 'trim|required|alpha|min_length[3]|max_length[50]');
        $this->form_validation->set_rules('surname', 'Surname', 'trim|required|alpha|min_length[3]|max_length[50]');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[user.email]');

	
	if ($this->form_validation->run() === FALSE){
	$this->load->view('templates/header', $data);
	$this->load->view('admin/edit', $data);
	$this->load->view('templates/footer');

	}else{

	$this->dashboard_model->set_dashboard($id);
	redirect( site_url('admin'));
	}
}

public function delete(){
		if (!$this->session->userdata('is_logged_in')and $this->session->userdata('usertype' == 1)
	{
		redirect(site_url('user/login'));
	}
	$id = $this->uri->segment(3);

	if (empty($id)){
		show_404();
	}

	$users = $this->user_model->get_userby_id($id);

	
	$this->user_model->delete_user($id);
	redirect(base_url().'index.php/admin');
	}
}