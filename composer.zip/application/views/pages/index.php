Home page
<h2><?php> echo $title;?><h2>
<table border='2' cellpadding='8'>
	<tr>
		<td><strong>Title</strong></td>
		<td><strong>Content</strong></td>
		<td><strong>Action</strong></td>
		<td><strong>?</strong></td>
	</tr>

	<?php foreach ($dashboard as $dashboard_item): ?>

		<tr>
		<td><?php echo $dashboard_item['title'] ?></td>
		<td><?php echo $dashboard_item['title'] ?></td>
		<td>
		<a href="<?php echo site_url('dsahboard/'.$dashboard_item['slug']);?>"View</a> |
		<a href="<?php echo site_url('dsahboard/edit/'.$dashboard_item['id']);?>"Edit</a> |
		<a href="<?php echo site_url('dsahboard/delete/'.$dashboard_item['id']);?>"onClick="return confirm('Are you sure you want to delete?');?>"Delete</a>
		</td>
		</tr>

	<?php endforeach;?>
</table>
	