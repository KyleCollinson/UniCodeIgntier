<p> Added Sucessfully!</p>
<p>
<a href="<?php echo site_url('admin/'); ?>">Back to admin page</a>
</p>